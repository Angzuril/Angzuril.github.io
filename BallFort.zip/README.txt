BallFort.exe - Application for the simple game.
BallFort_Data (Folder) - Contains stuff from the build that the executable needs to run.


Executable Details:
So this a quick game I wrote, where each player can control a ball, and you try to knowck the other players off the fort.

Once in-game, press space on the keyboard, or A on most controllers to join.

Once all players have joined, click launch game (you can do this with only 1 player)

Keyboard - WASD or Arrow Keys to move, mouse to look, Space to jump.
Left click would be used to hit other players, if there are any.
Press Escape to exit.

Controller - Joysticks to move/look, A to Jump, Right trigger to attack.
